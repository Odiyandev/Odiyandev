# Samp Disxord Connector Edited By Odiyan
This is a samp-discord connector filterscript which generally connects your samp server with discord. Everything is setuped in this filterscript you just have to put your channels ids.

Features Version - 0.1

1 - In-game chat feature.
2 - Discord commands like - /players , /serverinfo , /ip , /commands.
3 - Command log system (for this you have to shift the code to your main script).
4 - Server start message.
5 - Player connect/disconnect messages.
6 - Fixed discord-command include.

HOW TO ADD -..

1 - UPLOAD THAT ALL INCLUDE IN pawno >> include folder

2 - UPLOAD Discord.pwn This On  Filterscript folder And And Type Discord.pwn This Om cfg In filterscript line

3 - Add that All Cmd in the O-discord.pwn to Your Script Pawn And compile

ENJOY 



